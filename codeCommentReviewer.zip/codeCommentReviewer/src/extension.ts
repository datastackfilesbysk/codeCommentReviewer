import * as vscode from "vscode";

// This function is called when your extension is activated
export function activate(context: vscode.ExtensionContext) {
  // Register the command
  let disposable = vscode.commands.registerCommand(
    "extension.reviewComments",
    () => {
      // Get the active text editor
      const editor = vscode.window.activeTextEditor;
      if (editor) {
        const document = editor.document;
        // Check if the document language is C#
        if (document.languageId === "csharp") {
          // Get the text of the document
          const text = document.getText();
          // Extract comments, functions, and classes from the text
          const { comments, functions, classes } = extractDetails(text);

          // Display the extracted details
          vscode.window.showInformationMessage(
            `Found ${classes.length} classes and ${functions.length} functions with comments`
          );

          classes.forEach((cls) => {
            let classMessage = `Class: ${
              cls.name
            }\nComments:\n${cls.comments.join("\n")}`;
            vscode.window.showInformationMessage(classMessage);
          });

          functions.forEach((func) => {
            let functionMessage = `Function: ${
              func.name
            }\nComments:\n${func.comments.join("\n")}`;
            vscode.window.showInformationMessage(functionMessage);
          });
        } else {
          vscode.window.showInformationMessage(
            "This command only works on C# files."
          );
        }
      }
    }
  );

  // Add to the context's subscriptions
  context.subscriptions.push(disposable);
}

// Function to extract comments, functions, and classes from C# code
function extractDetails(text: string) {
  const commentRegex = /\/\/.*|\/\*[\s\S]*?\*\//g;
  const functionRegex =
    /(?:public|private|protected|internal|static|\s) +(?:async\s+)?(?:\w+\s+)+(\w+)\s*\(.*?\)\s*\{[^}]*\}/g;
  const classRegex =
    /(?:public|private|protected|internal|static|\s)+class\s+(\w+)/g;

  const comments = text.match(commentRegex) || [];
  const functions = [];
  const classes = [];

  let match;

  while ((match = functionRegex.exec(text)) !== null) {
    const func = {
      name: match[1],
      comments: extractCommentsAround(match.index, text),
    };
    functions.push(func);
  }

  while ((match = classRegex.exec(text)) !== null) {
    const cls = {
      name: match[1],
      comments: extractCommentsAround(match.index, text),
    };
    classes.push(cls);
  }

  return { comments, functions, classes };
}

// Function to extract comments around a specific index
function extractCommentsAround(index: number, text: string): string[] {
  const lines = text.substring(0, index).split("\n");
  const comments = [];
  for (let i = lines.length - 1; i >= 0; i--) {
    const line = lines[i].trim();
    if (
      line.startsWith("//") ||
      line.startsWith("/*") ||
      line.startsWith("*")
    ) {
      comments.unshift(line);
    } else {
      break;
    }
  }
  return comments;
}

// This function is called when your extension is deactivated
export function deactivate() {}
